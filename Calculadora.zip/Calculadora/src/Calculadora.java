

import java.util.Scanner;

public class Calculadora {
	
	private static Scanner calc;

	public static void main(String[] args) {
		System.out.println("Enter First and Second Number:");
		calc = new Scanner(System.in); 
		int num1,num2;
		num1 = calc.nextInt();
		num2 = calc.nextInt();
		
		System.out.println("Choose a Operation: 1 for Addition, 2 for subtraction, 3 for Multiplication, 4 for Division, 5 for NumToThePower, 6 for Fatorial(num1), 7 for DecToBinConvertion(num1):");
		int choose;
		choose = calc.nextInt();
		switch (choose) 
		{
		case 1 :
			System.out.println(add(num1,num2));
			break;
		case 2 :
			System.out.println(sub(num1,num2));
			break;
		case 3 :
			System.out.println(mult(num1,num2));
			break;
		case 4 :
			System.out.println(div(num1,num2));
			break;
		case 5 : 
			System.out.println(power(num1,num2));
			break;
		case 6 : 
			System.out.println(fat(num1));
			break;
		/*case 7 : 
			System.out.println(convert(num1));
			break;*/
			default:
				System.out.println("Invalid Operation");
		}
		

	}
	
	
	
	public static int add(int x, int y) {
		int result = x + y;
		return result;
	}
	
	public static int sub(int x, int y) {
		int result = x - y;
		return result;
	}
	
	public static int mult(int x, int y) {
		int result = x * y;
		return result;
	}
	
	public static int div(int x, int y) {
		int result = x/y;
		return result;
	}
	
	public static int power(int x, int y) {
		int result = 0;
		for(int i = 0; i<y; i++)
		result = result * x;
		return result;
		
	}
	
	public static int fat(int x) {
		int tot = 1;
		for (int cont= x; cont>=1; cont--)
			tot = tot*cont;
			return tot;
			
		
	}
			
}
